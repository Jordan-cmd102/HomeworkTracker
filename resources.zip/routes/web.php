<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\PostController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\HomeworkController;
use App\Http\Controllers\CourseController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ReplyController;
use App\Http\Controllers\TaskController;
use App\Http\Controllers\AdminUserController;
use App\Http\Controllers\AdminCourseController;
use App\Http\Controllers\AdminAssignmentController;
use App\Models\Task;
use App\Models\Post;

// ------------------------
// Static Pages
// ------------------------
Route::view('/', 'welcome');
Route::view('/register', 'register');
Route::view('/course', 'course');

// ------------------------
// Auth
// ------------------------
Route::post('/signup', [UserController::class, 'register']);
Route::post('/logout', [UserController::class, 'logout']);
Route::post('/login', [UserController::class, 'login']);
Route::get('/register', [AuthController::class, 'create'])->name('register');

// Student dashboard
Route::get('/student/dashboard', function () {
    return view('student.dashboard');
})->middleware('auth');
// ------------------------
// Forum
// ------------------------
Route::get('/forum', function () {
    $posts = Post::latest()->get();
    return view('forum', compact('posts'));
});
Route::post('/storePost', [PostController::class, 'addPost']);

Route::get('/view-my-posts', function () {
    $posts = auth()->check() ? auth()->user()->usersPosts()->latest()->get() : [];
    return view('myposts', ['myposts' => $posts]);
});

// ------------------------
// Homework (auth check inline)
// ------------------------
Route::resource('homework', HomeworkController::class)->middleware('auth');

// ------------------------
// Courses (auth check inline)
// ------------------------
Route::resource('courses', CourseController::class)->middleware('auth');

// ------------------------
// Dashboard (auth check inline)
// ------------------------
Route::get('/dashboard', function () {
    if (!auth()->check()) {
        return redirect('/login');
    }

    return app(DashboardController::class)->index();
})->name('dashboard');

// ------------------------
// Admin Dashboard (inline admin check)
// ------------------------
Route::get('/admin/dashboard', function () {
    if (!auth()->check() || !auth()->user()->is_admin) {
        abort(403, 'Unauthorized');
    }

    $tasks = Task::with('student')->get();
    return view('dashboard', compact('tasks'));
})->name('admin.dashboard');

// ------------------------
// Admin Panel Routes (inline admin check)
// ------------------------
Route::prefix('admin')->as('admin.')->group(function () {
    Route::get('/users', function () {
        if (!auth()->check() || !auth()->user()->is_admin) abort(403);
        return app(AdminUserController::class)->index();
    })->name('users.index');

    Route::get('/courses', function () {
        if (!auth()->check() || !auth()->user()->is_admin) abort(403);
        return app(AdminCourseController::class)->index();
    })->name('courses.index');

    Route::get('/assignments', function () {
        if (!auth()->check() || !auth()->user()->is_admin) abort(403);
        return app(AdminAssignmentController::class)->index();
    })->name('assignments.index');

    // Add other RESTful routes (store, create, update, delete) similarly if needed
});

Route::get('/tasks', [TaskController::class, 'index'])->name('tasks.index');
Route::get('/tasks/{task}', [TaskController::class, 'show'])->name('tasks.show');

// ------------------------
// Replies
// ------------------------
Route::post('/replies', [ReplyController::class, 'store'])->name('replies.store');

// ------------------------
// student login dashboard
// ------------------------
use App\Http\Controllers\StudentDashboardController;

Route::get('/student/dashboard', [StudentDashboardController::class, 'index'])
    ->middleware('auth')
    ->name('student.dashboard');


