<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Task extends Model
{
    // Tell Eloquent to use the 'homeworks' table instead of 'tasks'
    protected $table = 'homeworks';

    protected $fillable = ['title', 'due_date', 'student_id'];

    public function student()
    {
        return $this->belongsTo(User::class, 'user_id');
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }
}