<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Homework extends Model
{
    // This tells Laravel the correct table name
    protected $table = 'homeworks';  // plural, exactly your table name in DB

    protected $fillable = ['title', 'description', 'due_date', 'course_id', 'type', 'worth',   // add this
        'grade'];

    public function course()
    {
        return $this->belongsTo(Course::class);
    }
    public function user()
    {
        return $this->belongsTo(User::class);
    }




}


