<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Support\Facades\Auth;

class TaskController extends Controller
{
    // Show list of all tasks
    public function index()
    {
        $user = Auth::user();

        // Get only tasks assigned to the logged-in user
        $tasks = Task::with('user')->where('user_id', $user->id)->get();

        return view('tasks.index', compact('tasks'));
    }

    // Show a single task detail page
    public function show(Task $task)
    {
        // Make sure 'user' is loaded for the assigned user name
        $task->load('user');

        return view('tasks.show', compact('task'));
    }
}
