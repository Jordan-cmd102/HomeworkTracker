<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\Task;


class StudentDashboardController extends Controller
{
    public function index()
    {
        $user = Auth::user();

        // Only show tasks assigned to the logged-in student
        $homeworkTasks = Task::where('user_id', $user->id)
            ->where('type', 'homework')
            ->get();

        $assessmentTasks = Task::where('user_id', $user->id)
            ->where('type', 'assessment')
            ->get();
        // Merge tasks into calendar events
        $calendarEvents = $homeworkTasks->merge($assessmentTasks)->map(function ($task) {
            return [
                'title' => $task->title,
                'start' => $task->due_date,
                'id' => $task->id,
            ];
        });

        return view('student.dashboard', compact('homeworkTasks', 'assessmentTasks', 'calendarEvents'));
    }
}
