<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;
use App\Models\User;
class UserController extends Controller
{
    public function register(Request $request)
    {
        //Get data sent from HTML form
        $incomingFields = $request->validate([
            'name' => ['required', 'min:3', 'max:255'],
            'email' => ['required', 'email', Rule::unique('users', 'email')],
            'password' => ['required', 'min:3', 'max:200']
        ]);
        //Write user into table "users"
        $incomingFields['password'] = bcrypt($incomingFields['password']); //encrypt or hash password
        $user = User::create($incomingFields);
        Auth::login($user); //call utility function login() of auth() object
        return redirect()->back()->with('authenticaion-outcome', 'HI! WELCOME TO MY AWESOME WEBISTE!');
    }
    public function login(Request $request)
    {
        $credentials = $request->validate([
            'loginemail' => 'required|email',
            'loginpassword' => 'required',
        ]);

        if (Auth::attempt(['email' => $credentials['loginemail'], 'password' => $credentials['loginpassword']])) {
            $request->session()->regenerate();

            // Redirect based on role
            if (auth()->user()->role == 2) {
                return redirect()->route('student.dashboard');  // student dashboard route
            } elseif (auth()->user()->role == 0) {
                return redirect('/dashboard');  // admin or other role
            } else {
                return redirect('/'); // fallback
            }
        }

        return back()->withErrors([
            'loginemail' => 'The provided credentials do not match our records.',
        ]);
    }


    public function logout()
    {
        Auth::logout();
        return redirect()->back()->with('authenticaion-outcome', 'LOGGED OUT SUCCESSFULLY. BYE!');
    }
}