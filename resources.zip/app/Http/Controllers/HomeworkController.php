<?php

namespace App\Http\Controllers;

use App\Models\Homework;
use Illuminate\Http\Request;
use App\Models\Course;

class HomeworkController extends Controller
{
    public function index()
    {
        if (auth()->user()->is_admin) {
            // Admin sees all tasks
            $tasks = Homework::with('course', 'user')->get();
        } else {
            // Students see only their own tasks
            $tasks = Homework::with('course', 'user')
                ->where('user_id', auth()->id())
                ->get();
        }

        $courses = Course::all();

        return view('homework', compact('tasks', 'courses'));
    }

    public function store(Request $request)
    {
        // Validate the input
        $validatedData = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'due_date' => 'nullable|date',
            'course_id' => 'nullable|exists:courses,id',
            'type' => 'required|in:Homework,Assessment',
            'worth' => 'nullable|numeric|min:0|max:100',
            'grade' => 'nullable|numeric|min:0|max:100', // Updated to numeric
        ]);

        // Create a new Homework record and assign user_id
        $homework = new Homework();
        $homework->title = $validatedData['title'];
        $homework->description = $validatedData['description'] ?? null;
        $homework->due_date = $validatedData['due_date'] ?? null;
        $homework->course_id = $validatedData['course_id'] ?? null;
        $homework->type = $validatedData['type'];
        $homework->user_id = auth()->id();
        $homework->worth = $validatedData['worth'] ?? 0;
        $homework->grade = $validatedData['grade'] ?? null;

        $homework->save();

        return redirect()->route('homework.index')->with('success', 'Task added successfully!');
    }

    public function update(Request $request, Homework $homework)
    {
        // Validate the input
        $validatedData = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'due_date' => 'nullable|date',
            'course_id' => 'nullable|exists:courses,id',
            'type' => 'required|in:Homework,Assessment',
            'worth' => 'nullable|numeric|min:0|max:100',
            'grade' => 'nullable|numeric|min:0|max:100', // Updated to numeric
        ]);

        // Update fields
        $homework->title = $validatedData['title'];
        $homework->description = $validatedData['description'] ?? null;
        $homework->due_date = $validatedData['due_date'] ?? null;
        $homework->course_id = $validatedData['course_id'] ?? null;
        $homework->type = $validatedData['type'];
        $homework->worth = $validatedData['worth'] ?? 0;
        $homework->grade = $validatedData['grade'] ?? null;

        $homework->save();

        return redirect()->route('homework.index')->with('success', 'Task updated successfully!');
    }

    public function destroy($id)
    {
        $homework = Homework::findOrFail($id);

        // Ensure only the owner or an admin can delete
        if (!auth()->user()->is_admin && $homework->user_id !== auth()->id()) {
            abort(403, 'Unauthorized action.');
        }

        $homework->delete();

        return redirect()->back()->with('success', 'Task deleted.');
    }
}
