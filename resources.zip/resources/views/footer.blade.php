<div class="footer bg-dark text-white py-4">
    <div class="container text-center">
        <p class="mb-1">Created By Jordan Turner</p>
        <p class="mb-0">&copy; 2025</p>
    </div>
</div>

<!-- Add custom CSS for neutral, relaxing footer -->
<style>
    .footer {
        background: linear-gradient(135deg, #b8b8b8, #d4d4d4); /* Soft grey gradient for footer */
        color: #ffffff;
    }
</style>
