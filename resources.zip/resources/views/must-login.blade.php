@php
    $hour = date('H');
    $greeting = ($hour < 12) ? 'Good morning' : 'Please log in';
@endphp

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Login Required</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
</head>
<body>
<div class="container text-center mt-5">
    <h1 class="display-4 text-danger">{{ $greeting }}, you must log in to view this page</h1>
    <p>Please <a href="{{ route('login') }}">log in here</a> to continue.</p>
</div>
</body>
</html>
