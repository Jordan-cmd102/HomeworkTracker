@include('header')
@include('navbar')

<link rel="stylesheet" href="{{ asset('css/style.css') }}">

<div class="auth-container">
    @auth
        <div class="center-text">
            <p class="status-message">Congrats, you are logged in.</p>
            <form action="/logout" method="POST">
                @csrf
                <button class="logout-button">Log out</button>
            </form>
        </div>
    @else
        <div class="form-wrapper">
            <!-- Sign In -->
            <div class="form-box">
                <h3>Sign In</h3>

                {{-- Error Display --}}
                @if ($errors->has('login'))
                    <div class="error-message">{{ $errors->first('login') }}</div>
                @endif

                <form action="/login" method="POST">
                    @csrf
                    <label>User Name:</label><br>
                    <input name="loginemail" type="text" value="{{ old('loginemail') }}"><br><br>
                    <label>Password:</label><br>
                    <input name="loginpassword" type="password"><br><br>
                    <button class="auth-button">SIGN IN</button><br>
                    <a href="/forgot-password" class="forgot-link">Forgot Password?</a>
                </form>
            </div>

            <!-- Sign Up -->
            <div class="form-box">
                <h3>Sign Up</h3>
                <form action="/signup" method="POST">
                    @csrf
                    <label>User Name:</label><br>
                    <input name="name" type="text"><br><br>
                    <label>Password:</label><br>
                    <input name="password" type="password"><br><br>
                    <button class="auth-button">SIGN UP</button>
                </form>
            </div>
        </div>
    @endauth
</div>

@include('footer')
