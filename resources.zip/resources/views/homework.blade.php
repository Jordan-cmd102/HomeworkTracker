<!DOCTYPE html>
<html>

<head>
    <title>Homework/Assessment Tasks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
</head>

<body class="bg-light">

    @include('header')
    @include('navbar')

    <div class="container mt-5">
        <h1 class="text-center mb-4 text-primary">Homework/Assessment Tasks</h1>

        @if(session('success'))
            <div class="alert alert-success text-center">
                {{ session('success') }}
            </div>
        @endif

        <!-- Add New Task -->
        <div class="card mb-4 shadow-sm">
            <div class="card-body">
                <form method="POST" action="{{ route('homework.store') }}">
                    @csrf
                    <div class="row g-3 align-items-end">
                        <div class="col-md-2">
                            <label class="form-label">Title</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Description</label>
                            <input type="text" name="description" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Due Date</label>
                            <input type="date" name="due_date" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Type</label>
                            <select name="type" class="form-select" required>
                                <option value="">Select Type</option>
                                <option value="Homework">Homework</option>
                                <option value="Assessment">Assessment</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Course</label>
                            <select name="course_id" class="form-select" required>
                                <option value="">Select Course</option>
                                @foreach($courses as $course)
                                    <option value="{{ $course->id }}">{{ $course->title }}</option>
                                @endforeach
                            </select>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Worth (%)</label>
                            <input type="number" name="worth" id="worth" class="form-control" min="0" max="100"
                                step="0.1" required>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Grade</label>
                            <input type="number" name="grade" id="grade" class="form-control" min="0" max="100"
                                step="0.1">
                        </div>
                        <div class="col-md-1">
                            <button type="submit" class="btn btn-primary w-100">Add</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tasks Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Due Date</th>
                        <th>Type</th>
                        <th>Course</th>
                        <th colspan="2">Grade Details</th> {{-- This spans two cells below --}}
                        <th>Student</th>

                        <th>Actions</th>
                    </tr>
                    <tr>
                        <th colspan="5"></th>
                        <th>Worth (%)</th>
                        <th>Grade</th>
                        @if(auth()->user()->is_admin)
                            <th></th>
                        @endif
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    @forelse($tasks as $task)
                        @if(request('edit') == $task->id)
                            <tr>
                                <form method="POST" action="{{ route('homework.update', $task->id) }}">
                                    @csrf
                                    @method('PUT')
                                    <td>
                                        <input type="text" name="title" class="form-control" value="{{ $task->title }}"
                                            required>
                                    </td>
                                    <td>
                                        <input type="text" name="description" class="form-control"
                                            value="{{ $task->description }}">
                                    </td>
                                    <td>
                                        <input type="date" name="due_date" class="form-control" value="{{ $task->due_date }}">
                                    </td>
                                    <td>
                                        <select name="type" class="form-select" required>
                                            <option value="Homework" @selected($task->type == 'Homework')>Homework</option>
                                            <option value="Assessment" @selected($task->type == 'Assessment')>Assessment</option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="course_id" class="form-select" required>
                                            @foreach($courses as $course)
                                                <option value="{{ $course->id }}" @selected($course->id == $task->course_id)>
                                                    {{ $course->title }}
                                                </option>
                                            @endforeach
                                        </select>
                                    </td>
                                    <td>
                                        <input type="number" name="worth" class="form-control" value="{{ $task->worth ?? '' }}"
                                            min="0" max="100" step="0.1">
                                    </td>
                                    <td>
                                        <input type="number" name="grade" class="form-control" value="{{ $task->grade ?? '' }}"
                                            min="0" max="100" step="0.1">
                                        @if($task->grade !== null && $task->worth !== null)
                                            <small class="text-muted d-block">→ Final:
                                                {{ round($task->grade * ($task->worth / 100), 2) }}%</small>
                                        @endif
                                    </td>
                                    @if(auth()->user()->is_admin)
                                        <td>{{ $task->user->name ?? 'Unknown' }}</td>
                                    @endif
                                    <td class="d-flex gap-2">
                                        <button type="submit" class="btn btn-success btn-sm">Save</button>
                                        <a href="{{ route('homework.index') }}" class="btn btn-secondary btn-sm">Cancel</a>
                                    </td>
                                </form>
                            </tr>
                        @else
                            <tr>
                                <td>{{ $task->title }}</td>
                                <td>{{ $task->description }}</td>
                                <td>{{ $task->due_date }}</td>
                                <td>{{ $task->type ?? 'N/A' }}</td>
                                <td>{{ $task->course->title ?? 'N/A' }}</td>
                                <td>{{ $task->worth ?? 'N/A' }}</td>
                                <td>
                                    @if($task->grade !== null)
                                        {{ $task->grade }}/100<br>
                                        @if($task->worth !== null)
                                            <small class="text-muted">→ Final:
                                                {{ round($task->grade * ($task->worth / 100), 2) }}%</small>
                                        @endif
                                    @else
                                        N/A
                                    @endif
                                </td>
                                @if(auth()->user()->is_admin)
                                    <td>{{ $task->user->name ?? 'Unknown' }}</td>
                                @endif
                                <td class="d-flex gap-2">
                                    <a href="{{ route('homework.index', ['edit' => $task->id]) }}"
                                        class="btn btn-warning btn-sm">Edit</a>
                                    <form method="POST" action="{{ route('homework.destroy', $task->id) }}">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        @endif
                    @empty
                        <tr>
                            <td colspan="{{ auth()->user()->is_admin ? 9 : 8 }}" class="text-center text-muted">
                                No homework/assessment tasks available.
                            </td>
                        </tr>
                    @endforelse
                </tbody>

            </table>
        </div>
    </div>

    @include('footer')

</body>

</html>