<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="/css/auth.css"> <!-- Your CSS -->
</head>
<body>
    <div class="auth-container">
        <h2>Forgot Password</h2>

        @if (session('status'))
            <div class="success">{{ session('status') }}</div>
        @endif

        @if ($errors->any())
            <div class="errors">
                @foreach ($errors->all() as $error)
                    <p>{{ $error }}</p>
                @endforeach
            </div>
        @endif

        <form method="POST" action="/forgot-password">
            @csrf
            <input type="email" name="email" placeholder="Enter your email" required><br>
            <button type="submit">Send Password Reset Link</button>
        </form>

        <a href="/auth">← Back to login</a>
    </div>
</body>
</html>
