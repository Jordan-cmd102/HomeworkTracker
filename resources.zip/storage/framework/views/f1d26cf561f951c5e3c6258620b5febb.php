<!DOCTYPE html>
<html>

<head>
    <title>Homework/Assessment Tasks</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
</head>

<body class="bg-light">

    <?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="container mt-5">
        <h1 class="text-center mb-4 text-primary">Homework/Assessment Tasks</h1>

        <?php if(session('success')): ?>
            <div class="alert alert-success text-center">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <!-- Add New Task -->
        <div class="card mb-4 shadow-sm">
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('homework.store')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="row g-3 align-items-end">
                        <div class="col-md-2">
                            <label class="form-label">Title</label>
                            <input type="text" name="title" class="form-control" required>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label">Description</label>
                            <input type="text" name="description" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Due Date</label>
                            <input type="date" name="due_date" class="form-control">
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Type</label>
                            <select name="type" class="form-select" required>
                                <option value="">Select Type</option>
                                <option value="Homework">Homework</option>
                                <option value="Assessment">Assessment</option>
                            </select>
                        </div>
                        <div class="col-md-2">
                            <label class="form-label">Course</label>
                            <select name="course_id" class="form-select" required>
                                <option value="">Select Course</option>
                                <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($course->id); ?>"><?php echo e($course->title); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Worth (%)</label>
                            <input type="number" name="worth" id="worth" class="form-control" min="0" max="100"
                                step="0.1" required>
                        </div>
                        <div class="col-md-1">
                            <label class="form-label">Grade</label>
                            <input type="number" name="grade" id="grade" class="form-control" min="0" max="100"
                                step="0.1">
                        </div>
                        <div class="col-md-1">
                            <button type="submit" class="btn btn-primary w-100">Add</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <!-- Tasks Table -->
        <div class="table-responsive">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>Title</th>
                        <th>Description</th>
                        <th>Due Date</th>
                        <th>Type</th>
                        <th>Course</th>
                        <th colspan="2">Grade Details</th> 
                        <th>Student</th>

                        <th>Actions</th>
                    </tr>
                    <tr>
                        <th colspan="5"></th>
                        <th>Worth (%)</th>
                        <th>Grade</th>
                        <?php if(auth()->user()->is_admin): ?>
                            <th></th>
                        <?php endif; ?>
                        <th></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php if(request('edit') == $task->id): ?>
                            <tr>
                                <form method="POST" action="<?php echo e(route('homework.update', $task->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PUT'); ?>
                                    <td>
                                        <input type="text" name="title" class="form-control" value="<?php echo e($task->title); ?>"
                                            required>
                                    </td>
                                    <td>
                                        <input type="text" name="description" class="form-control"
                                            value="<?php echo e($task->description); ?>">
                                    </td>
                                    <td>
                                        <input type="date" name="due_date" class="form-control" value="<?php echo e($task->due_date); ?>">
                                    </td>
                                    <td>
                                        <select name="type" class="form-select" required>
                                            <option value="Homework" <?php if($task->type == 'Homework'): echo 'selected'; endif; ?>>Homework</option>
                                            <option value="Assessment" <?php if($task->type == 'Assessment'): echo 'selected'; endif; ?>>Assessment</option>
                                        </select>
                                    </td>
                                    <td>
                                        <select name="course_id" class="form-select" required>
                                            <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($course->id); ?>" <?php if($course->id == $task->course_id): echo 'selected'; endif; ?>>
                                                    <?php echo e($course->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </td>
                                    <td>
                                        <input type="number" name="worth" class="form-control" value="<?php echo e($task->worth ?? ''); ?>"
                                            min="0" max="100" step="0.1">
                                    </td>
                                    <td>
                                        <input type="number" name="grade" class="form-control" value="<?php echo e($task->grade ?? ''); ?>"
                                            min="0" max="100" step="0.1">
                                        <?php if($task->grade !== null && $task->worth !== null): ?>
                                            <small class="text-muted d-block">→ Final:
                                                <?php echo e(round($task->grade * ($task->worth / 100), 2)); ?>%</small>
                                        <?php endif; ?>
                                    </td>
                                    <?php if(auth()->user()->is_admin): ?>
                                        <td><?php echo e($task->user->name ?? 'Unknown'); ?></td>
                                    <?php endif; ?>
                                    <td class="d-flex gap-2">
                                        <button type="submit" class="btn btn-success btn-sm">Save</button>
                                        <a href="<?php echo e(route('homework.index')); ?>" class="btn btn-secondary btn-sm">Cancel</a>
                                    </td>
                                </form>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td><?php echo e($task->title); ?></td>
                                <td><?php echo e($task->description); ?></td>
                                <td><?php echo e($task->due_date); ?></td>
                                <td><?php echo e($task->type ?? 'N/A'); ?></td>
                                <td><?php echo e($task->course->title ?? 'N/A'); ?></td>
                                <td><?php echo e($task->worth ?? 'N/A'); ?></td>
                                <td>
                                    <?php if($task->grade !== null): ?>
                                        <?php echo e($task->grade); ?>/100<br>
                                        <?php if($task->worth !== null): ?>
                                            <small class="text-muted">→ Final:
                                                <?php echo e(round($task->grade * ($task->worth / 100), 2)); ?>%</small>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        N/A
                                    <?php endif; ?>
                                </td>
                                <?php if(auth()->user()->is_admin): ?>
                                    <td><?php echo e($task->user->name ?? 'Unknown'); ?></td>
                                <?php endif; ?>
                                <td class="d-flex gap-2">
                                    <a href="<?php echo e(route('homework.index', ['edit' => $task->id])); ?>"
                                        class="btn btn-warning btn-sm">Edit</a>
                                    <form method="POST" action="<?php echo e(route('homework.destroy', $task->id)); ?>">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"
                                            onclick="return confirm('Are you sure?')">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="<?php echo e(auth()->user()->is_admin ? 9 : 8); ?>" class="text-center text-muted">
                                No homework/assessment tasks available.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>

    <?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html><?php /**PATH C:\xampp\htdocs\homework-tracker\tracker\resources\views/homework.blade.php ENDPATH**/ ?>