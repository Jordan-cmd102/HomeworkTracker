
<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container my-5">
    <h1><?php echo e($task->title); ?></h1>
    <p><strong>Due Date:</strong> <?php echo e($task->due_date); ?></p>
    <p><strong>Assigned to:</strong> <?php echo e($task->user->name ?? 'Unknown'); ?></p>
    <p><strong>Description:</strong> <?php echo e($task->description); ?></p>
</div>

<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php /**PATH C:\xampp\htdocs\homework-tracker\tracker\resources\views/tasks/show.blade.php ENDPATH**/ ?>