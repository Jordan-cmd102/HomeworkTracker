<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
<!-- FullCalendar CSS -->
<link href='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.7/index.global.min.css' rel='stylesheet' />

<div class="container my-5">

    <section class="mb-5">
        <h3>My Homework Tasks</h3>
        <?php if($homeworkTasks->isEmpty()): ?>
            <p>No homework tasks found.</p>
        <?php else: ?>
            <ul>
                <?php $__currentLoopData = $homeworkTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('tasks.show', $task->id)); ?>">
                            <strong><?php echo e($task->title); ?></strong> - Due: <?php echo e($task->due_date); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>

        <h3>My Assessment Tasks</h3>
        <?php if($assessmentTasks->isEmpty()): ?>
            <p>No assessment tasks found.</p>
        <?php else: ?>
            <ul>
                <?php $__currentLoopData = $assessmentTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route('tasks.show', $task->id)); ?>">
                            <strong><?php echo e($task->title); ?></strong> - Due: <?php echo e($task->due_date); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php endif; ?>
    </section>


    <section>
        <h2 class="mb-3">Task Calendar</h2>
        <div id="calendar" class="border rounded p-3 shadow-sm bg-white"></div>
    </section>
</div>

<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- FullCalendar JS -->
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.7/index.global.min.js'></script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            navLinks: true,
            selectable: false,
            nowIndicator: true,
            events: [
                <?php $__currentLoopData = $calendarEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        {
                        title: '<?php echo e(addslashes($event['title'])); ?>',
                        start: '<?php echo e($event['start']); ?>',
                        allDay: true,
                        url: '<?php echo e(route("tasks.show", $event['id'])); ?>' // Link to task detail page
                    },
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            ],
            eventClick: function (info) {
                info.jsEvent.preventDefault(); // Prevent browser's default action
                if (info.event.url) {
                    window.location.href = info.event.url; // Navigate to task detail
                }
            }
        });

        calendar.render();
    });
</script><?php /**PATH C:\xampp\htdocs\homework-tracker\tracker\resources\views/dashboard.blade.php ENDPATH**/ ?>