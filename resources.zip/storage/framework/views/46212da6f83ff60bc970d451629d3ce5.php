<!-- Bootstrap CSS -->
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

<!-- Your Custom Styles (loaded after Bootstrap) -->
<link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">


<nav class="navbar navbar-expand-lg custom-navbar">
    <div class="container">
        <a class="navbar-brand" href="#">Home</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ms-auto">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/register')); ?>">Register</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/homework')); ?>">All Tasks</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('courses.index')); ?>">Courses</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/forum')); ?>">Forum</a>
                </li>

                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role === 0): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(url('/dashboard')); ?>">Dashboard</a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(auth()->guard()->check()): ?>
                    <?php if(auth()->user()->role == 2): ?> <!-- role 2 = student -->
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('student.dashboard')); ?>">Dashboard</a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav><?php /**PATH C:\xampp\htdocs\homework-tracker\tracker\resources\views/navbar.blade.php ENDPATH**/ ?>