<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main>
    <div class="main-title">
        <h2>FORUM PAGE</h2>
    </div>

    <!-- Displaying Feedback to the User -->
    <?php if(session()->has('outcome')): ?>
        <p class="center-text status-message"><?php echo e(session()->get('outcome')); ?></p>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <ul class="center-text error-list">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <!-- Form to create a new post -->
    <div class="form-box forum-form">
        <h2>Create a New Topic</h2>
        <form action="/storePost" method="POST">
            <?php echo csrf_field(); ?>
            <label for="title">Title</label>
            <input type="text" name="title" placeholder="Post title">

            <label for="body">Body</label>
            <textarea name="body" placeholder="Body content..." rows="5"></textarea>

            <button class="auth-button">CREATE</button>
        </form>
    </div>

    <!-- List all existing posts -->
    <div class="forum-posts">
        <h2>All Posts:</h2>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="post-card">
                <h3><?php echo e($post['title']); ?></h3>
                <h5>By: <?php echo e($post->user->name); ?></h5>
                <p>Date: <?php echo e($post->created_at); ?></p>
                <p><?php echo e($post['body']); ?></p>
            </div>
            <!-- Show Replies -->
            <?php if($post->replies->count()): ?>
                <div class="replies">
                    <h4>Replies:</h4>
                    <?php $__currentLoopData = $post->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="reply">
                            <strong><?php echo e($reply->user->name); ?>:</strong>
                            <p><?php echo e($reply->body); ?></p>
                            <small><?php echo e($reply->created_at); ?></small>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>

            <!-- Reply Form -->
            <div class="reply-form">
                <form action="<?php echo e(route('replies.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
                    <textarea name="body" rows="3" placeholder="Write a reply..." required></textarea>
                    <button type="submit">Reply</button>
                </form>
            </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</main>

<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\homework-tracker\tracker\resources\views/forum.blade.php ENDPATH**/ ?>