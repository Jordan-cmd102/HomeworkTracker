<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<!-- MAIN AREA -->
<div class="container mt-5">
    <div class="text-center mb-4">
        <h1 class="display-4 fw-bold text-primary">Welcome to Your Homework & Assessment Tracker</h1>
        <p class="lead text-muted">Organize your studies, track deadlines, and stay ahead of your academic goals.</p>
    </div>

    <div class="row justify-content-center">
        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <i class="bi bi-book-fill display-4 text-info mb-3"></i>
                    <h5 class="card-title">Manage Courses</h5>
                    <p class="card-text">Add, edit, or remove your subjects and associate tasks easily.</p>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('courses.index')); ?>" class="btn btn-outline-primary">View Courses</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary">Register to Access</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <i class="bi bi-check2-square display-4 text-success mb-3"></i>
                    <h5 class="card-title">Track Assessments</h5>
                    <p class="card-text">Stay on top of upcoming assignments, homework, and exams.</p>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('homework.index')); ?>" class="btn btn-outline-success">View Assessments</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-success">Register to Access</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card shadow-sm h-100">
                <div class="card-body text-center">
                    <i class="bi bi-bar-chart-fill display-4 text-warning mb-3"></i>
                    <h5 class="card-title">Progress Overview</h5>
                    <p class="card-text">Visualize your progress and improve your study habits.</p>
                    <?php if(auth()->guard()->check()): ?>
                        <a href="<?php echo e(route('dashboard')); ?>" class="btn btn-outline-warning">Go to Dashboard</a>
                    <?php else: ?>
                        <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-warning">Register to Access</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

</div>
</div>
</div>
</div>

<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\homework-tracker\tracker\resources\views/welcome.blade.php ENDPATH**/ ?>