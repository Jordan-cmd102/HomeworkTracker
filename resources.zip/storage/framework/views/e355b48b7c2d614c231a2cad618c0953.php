<?php echo $__env->make('header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="container py-5">
    <div class="text-center mb-5">
        <h1 class="main-title">Register Page</h1>
    </div>

    <!-- Displaying Feedback to the User -->
    <?php if(session()->has('authentication-outcome')): ?>
        <div class="alert alert-info text-center"><?php echo e(session()->get('authentication-outcome')); ?></div>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <ul class="alert alert-danger text-center error-list">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <div class="alert alert-success text-center auth-success">
            <p>Congrats, you are logged in.</p>
            <!-- Logout Button -->
            <form action="/logout" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <button class="logout-button">Log out</button>
            </form>
        </div>
    <?php else: ?>
        <div class="auth-container">
            <!-- Register Form -->
            <div class="form-box">
                <h3>Register</h3>
                <form action="/signup" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <label for="name" class="form-label">Name</label>
                        <input name="name" type="text" class="form-control" placeholder="Enter your name" required>
                    </div>
                    <div class="input-group">
                        <label for="email" class="form-label">Email</label>
                        <input name="email" type="email" class="form-control" placeholder="Enter your email" required>
                    </div>
                    <div class="input-group">
                        <label for="password" class="form-label">Password</label>
                        <input name="password" type="password" class="form-control" placeholder="Enter your password"
                            required>
                    </div>
                    <button type="submit" class="auth-button">Register</button>
                </form>
            </div>

            <!-- Login Form -->
            <div class="form-box">
                <h3>Login</h3>
                <form action="/login" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="input-group">
                        <label for="loginemail" class="form-label">Email</label>
                        <input name="loginemail" type="email" class="form-control" placeholder="Enter your email" required>
                    </div>
                    <div class="input-group">
                        <label for="loginpassword" class="form-label">Password</label>
                        <input name="loginpassword" type="password" class="form-control" placeholder="Enter your password"
                            required>
                    </div>
                    <button type="submit" class="auth-button">Log in</button>
                </form>
            </div>
        </div>
    <?php endif; ?>
</main>

<?php echo $__env->make('footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\homework-tracker\tracker\resources\views/register.blade.php ENDPATH**/ ?>