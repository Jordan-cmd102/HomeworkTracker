@include('header')
@include('navbar')

<link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
<!-- FullCalendar CSS -->
<link href='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.7/index.global.min.css' rel='stylesheet' />

<div class="container my-5">

    <section class="mb-5">
        <h3>My Homework Tasks</h3>
        @if($homeworkTasks->isEmpty())
            <p>No homework tasks found.</p>
        @else
            <ul>
                @foreach ($homeworkTasks as $task)
                    <li>
                        <a href="{{ route('tasks.show', $task->id) }}">
                            <strong>{{ $task->title }}</strong> - Due: {{ $task->due_date }}
                        </a>
                    </li>
                @endforeach
            </ul>
        @endif

        <h3>My Assessment Tasks</h3>
        @if($assessmentTasks->isEmpty())
            <p>No assessment tasks found.</p>
        @else
            <ul>
                @foreach ($assessmentTasks as $task)
                    <li>
                        <a href="{{ route('tasks.show', $task->id) }}">
                            <strong>{{ $task->title }}</strong> - Due: {{ $task->due_date }}
                        </a>
                    </li>
                @endforeach
            </ul>
        @endif
    </section>


    <section>
        <h2 class="mb-3">Task Calendar</h2>
        <div id="calendar" class="border rounded p-3 shadow-sm bg-white"></div>
    </section>
</div>

@include('footer')

<!-- FullCalendar JS -->
<script src='https://cdn.jsdelivr.net/npm/fullcalendar@6.1.7/index.global.min.js'></script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var calendarEl = document.getElementById('calendar');

        var calendar = new FullCalendar.Calendar(calendarEl, {
            initialView: 'dayGridMonth',
            headerToolbar: {
                left: 'prev,next today',
                center: 'title',
                right: 'dayGridMonth,timeGridWeek,timeGridDay'
            },
            navLinks: true,
            selectable: false,
            nowIndicator: true,
            events: [
                @foreach($calendarEvents as $event)
                        {
                        title: '{{ addslashes($event['title']) }}',
                        start: '{{ $event['start'] }}',
                        allDay: true,
                        url: '{{ route("tasks.show", $event['id']) }}' // Link to task detail page
                    },
                @endforeach
            ],
            eventClick: function (info) {
                info.jsEvent.preventDefault(); // Prevent browser's default action
                if (info.event.url) {
                    window.location.href = info.event.url; // Navigate to task detail
                }
            }
        });

        calendar.render();
    });
</script>