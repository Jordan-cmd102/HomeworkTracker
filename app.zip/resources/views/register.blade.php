@include('header')
@include('navbar')

<main class="container py-5">
    <div class="text-center mb-5">
        <h1 class="main-title">Register Page</h1>
    </div>

    <!-- Displaying Feedback to the User -->
    @if(session()->has('authentication-outcome'))
        <div class="alert alert-info text-center">{{ session()->get('authentication-outcome') }}</div>
    @endif

    @if ($errors->any())
        <ul class="alert alert-danger text-center error-list">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

    @auth
        <div class="alert alert-success text-center auth-success">
            <p>Congrats, you are logged in.</p>
            <!-- Logout Button -->
            <form action="/logout" method="POST" class="d-inline">
                @csrf
                <button class="logout-button">Log out</button>
            </form>
        </div>
    @else
        <div class="auth-container">
            <!-- Register Form -->
            <div class="form-box">
                <h3>Register</h3>
                <form action="/signup" method="POST">
                    @csrf
                    <div class="input-group">
                        <label for="name" class="form-label">Name</label>
                        <input name="name" type="text" class="form-control" placeholder="Enter your name" required>
                    </div>
                    <div class="input-group">
                        <label for="email" class="form-label">Email</label>
                        <input name="email" type="email" class="form-control" placeholder="Enter your email" required>
                    </div>
                    <div class="input-group">
                        <label for="password" class="form-label">Password</label>
                        <input name="password" type="password" class="form-control" placeholder="Enter your password"
                            required>
                    </div>
                    <button type="submit" class="auth-button">Register</button>
                </form>
            </div>

            <!-- Login Form -->
            <div class="form-box">
                <h3>Login</h3>
                <form action="/login" method="POST">
                    @csrf
                    <div class="input-group">
                        <label for="loginemail" class="form-label">Email</label>
                        <input name="loginemail" type="email" class="form-control" placeholder="Enter your email" required>
                    </div>
                    <div class="input-group">
                        <label for="loginpassword" class="form-label">Password</label>
                        <input name="loginpassword" type="password" class="form-control" placeholder="Enter your password"
                            required>
                    </div>
                    <button type="submit" class="auth-button">Log in</button>
                </form>
            </div>
        </div>
    @endauth
</main>

@include('footer')