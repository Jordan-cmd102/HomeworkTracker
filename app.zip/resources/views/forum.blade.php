@include('header')
@include('navbar')

<main>
    <div class="main-title">
        <h2>FORUM PAGE</h2>
    </div>

    <!-- Displaying Feedback to the User -->
    @if(session()->has('outcome'))
        <p class="center-text status-message">{{ session()->get('outcome') }}</p>
    @endif

    @if ($errors->any())
        <ul class="center-text error-list">
            @foreach ($errors->all() as $error)
                <li>{{ $error }}</li>
            @endforeach
        </ul>
    @endif

    <!-- Form to create a new post -->
    <div class="form-box forum-form">
        <h2>Create a New Topic</h2>
        <form action="/storePost" method="POST">
            @csrf
            <label for="title">Title</label>
            <input type="text" name="title" placeholder="Post title">

            <label for="body">Body</label>
            <textarea name="body" placeholder="Body content..." rows="5"></textarea>

            <button class="auth-button">CREATE</button>
        </form>
    </div>

    <!-- List all existing posts -->
    <div class="forum-posts">
        <h2>All Posts:</h2>
        @foreach($posts as $post)
            <div class="post-card">
                <h3>{{ $post['title'] }}</h3>
                <h5>By: {{ $post->user->name }}</h5>
                <p>Date: {{ $post->created_at }}</p>
                <p>{{ $post['body'] }}</p>
            </div>
            <!-- Show Replies -->
            @if($post->replies->count())
                <div class="replies">
                    <h4>Replies:</h4>
                    @foreach($post->replies as $reply)
                        <div class="reply">
                            <strong>{{ $reply->user->name }}:</strong>
                            <p>{{ $reply->body }}</p>
                            <small>{{ $reply->created_at }}</small>
                        </div>
                    @endforeach
                </div>
            @endif

            <!-- Reply Form -->
            <div class="reply-form">
                <form action="{{ route('replies.store') }}" method="POST">
                    @csrf
                    <input type="hidden" name="post_id" value="{{ $post->id }}">
                    <textarea name="body" rows="3" placeholder="Write a reply..." required></textarea>
                    <button type="submit">Reply</button>
                </form>
            </div>

        @endforeach
    </div>
</main>

@include('footer')