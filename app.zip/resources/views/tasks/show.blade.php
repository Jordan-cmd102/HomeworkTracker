{{-- resources/views/tasks/show.blade.php --}}
@include('header')
@include('navbar')

<div class="container my-5">
    <h1>{{ $task->title }}</h1>
    <p><strong>Due Date:</strong> {{ $task->due_date }}</p>
    <p><strong>Assigned to:</strong> {{ $task->user->name ?? 'Unknown' }}</p>
    <p><strong>Description:</strong> {{ $task->description }}</p>
</div>

@include('footer')
