<?php
namespace Database\Seeders;
use App\Models\User;
// use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Message;
use App\Models\Post;
class DatabaseSeeder extends Seeder
{
/**
* Seed the application's database.
*/
public function run(): void
{
//Create 20 fake messages
Message::factory(20)->create();
//Create 10 fake users
User::factory(10)->create();
//Create 20 fake posts
Post::factory(20)->create();
}
}