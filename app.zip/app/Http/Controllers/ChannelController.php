<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\Models\Channel;
class ChannelController extends Controller
{
    public function index()
    {
        return Channel::all();
    }

    public function store(Request $request)
    {
        $request->validate(['name' => 'required']);
        return Channel::create($request->all());
    }

    public function show(Channel $channel)
    {
        return $channel->load('messages.user');
    }
public function forum($id = null)
{
    $channels = Channel::all();
    $selectedChannel = $id ? Channel::with('messages.user')->findOrFail($id) : null;

    return view('forum', compact('channels', 'selectedChannel'));
}

}
