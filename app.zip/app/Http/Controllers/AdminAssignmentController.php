<?php

namespace App\Http\Controllers;

use App\Models\Task;
use Illuminate\Http\Request;

class AdminAssignmentController extends Controller
{
    public function index()
    {
        $assignments = Task::all();
        return view('admin.assignments.index', compact('assignments'));
    }

    public function create()
    {
        return view('admin.assignments.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'title' => 'required',
            'due_date' => 'required|date'
        ]);

        Task::create($request->all());

        return redirect()->route('assignments.index')->with('success', 'Assignment created.');
    }

    public function show(Task $task)
    {
        return view('admin.assignments.show', compact('assignment'));
    }

    public function edit(Task $task)
    {
        return view('admin.assignments.edit', compact('assignment'));
    }

    public function update(Request $request, Task $task)
    {
        $request->validate([
            'title' => 'required',
            'due_date' => 'required|date'
        ]);

        $task->update($request->all());

        return redirect()->route('assignments.index')->with('success', 'Assignment updated.');
    }

    public function destroy(Task $task)
    {
        $task->delete();
        return redirect()->route('assignments.index')->with('success', 'Assignment deleted.');
    }
}
