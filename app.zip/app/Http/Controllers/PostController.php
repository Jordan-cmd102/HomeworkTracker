<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Post;
class PostController extends Controller
{
public function addPost(Request $request) {
//Catch data sent from client-side HTML form
$incomingFields = $request->validate([
'title' => 'required',
'body' => 'required'
]);
//Clean up received data
$incomingFields['title'] = strip_tags($incomingFields['title']);
$incomingFields['body'] = strip_tags($incomingFields['body']);
$incomingFields['user_id'] = auth()->id();//get user_id
//Check if logged-in or not.
if (is_null(auth()->id())) {
//User not login yet. Redirect back to "forum" view
return redirect()->back()->with('outcome', 'Not login yet. Please go to LOGIN page to login');
} else {
Post::create($incomingFields); //Post::create - add a new post to "posts" table
//Use logged-in. Redirect back to "forum" view
return redirect()->back()->with('outcome', 'Your post has been added successfully!');
}
}
}