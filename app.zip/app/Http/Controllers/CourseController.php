<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class CourseController extends Controller
{
public function index()
{
    if (!Auth::check()) {
        // Show a custom view if not logged in
        return view('auth.must-login');
    }

    $courses = Course::all();
    return view('course', compact('courses'));
}


    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'image' => 'required|image|max:2048'
        ]);

        $path = $request->file('image')->store('courses', 'public');

        Course::create([
            'title' => $validated['title'],
            'description' => $validated['description'],
            'image_path' => $path
        ]);

        return redirect()->route('courses.index')->with('success', 'Course added!');
    }

    public function update(Request $request, Course $course)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'required|string',
            'image' => 'nullable|image|max:2048'
        ]);

        if ($request->hasFile('image')) {
            if ($course->image_path) {
                Storage::disk('public')->delete($course->image_path);
            }
            $path = $request->file('image')->store('courses', 'public');
            $course->image_path = $path;
        }

        $course->title = $validated['title'];
        $course->description = $validated['description'];
        $course->save();

        return redirect()->route('courses.index')->with('success', 'Course updated!');
    }

    public function destroy(Course $course)
    {
        if ($course->image_path) {
            Storage::disk('public')->delete($course->image_path);
        }

        $course->delete();
        return redirect()->route('courses.index')->with('success', 'Course deleted!');
    }
}
