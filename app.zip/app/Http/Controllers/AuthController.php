<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\User;
use Illuminate\Support\Facades\Hash;

class AuthController extends Controller
{
    // Show login/register form (optional if you use a Blade view directly)
    public function show()
    {
        return view('auth'); // Make sure this matches your blade filename
    }

    // Handle Login
    public function login(Request $request)
    {
        $credentials = [
            'email' => $request->input('loginemail'),
            'password' => $request->input('loginpassword'),
        ];

        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
            return redirect('/');
        }

        return back()->withErrors([
            'login' => 'The provided credentials do not match our records.',
        ])->withInput();
    }

    // Handle Sign Up
    public function signup(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'password' => 'required|string|min:6',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => strtolower($request->name) . '@student.local', // Auto-email example
            'password' => Hash::make($request->password),
        ]);

        Auth::login($user);

        return redirect('/');
    }

    // Handle Logout
    public function logout(Request $request)
    {
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        return redirect('/');
    }

public function create()
{
    return view('register'); // This means Laravel looks for resources/views/auth/register.blade.php
}
}
