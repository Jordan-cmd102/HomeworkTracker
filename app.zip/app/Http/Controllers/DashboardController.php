<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Course;
use App\Models\Task;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function index()
    {
        // Prepare calendar events with related user info
        $calendarEvents = Task::with('user')->get()->map(function ($task) {
            return [
                'id' => $task->id,
                'title' => $task->title,
                'start' => $task->due_date,
                'description' => $task->description ?? 'No description',
                'assigned_to' => $task->user->name ?? 'Unknown',
            ];
        });

        // Also fetch homeworkTasks and assessmentTasks for the dashboard if needed
        $homeworkTasks = Task::where('type', 'homework')->get();
        $assessmentTasks = Task::where('type', 'assessment')->get();

        // Pass all data to your dashboard Blade view
        return view('dashboard', compact('calendarEvents', 'homeworkTasks', 'assessmentTasks'));
    }
}
