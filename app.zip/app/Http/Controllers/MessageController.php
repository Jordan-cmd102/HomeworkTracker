<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use app\Models\Channel;
class MessageController extends Controller
{
    public function store(Request $request, Channel $channel)
    {
        $request->validate(['body' => 'required']);
        return $channel->messages()->create([
            'user_id' => auth()->id(),
            'body' => $request->body
        ]);
    }
}

